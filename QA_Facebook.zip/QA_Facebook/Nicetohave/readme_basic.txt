1. page_login.py -> Acest cod definește o clasă LoginPage care conține metode pentru a introduce un nume de utilizator și o parolă, a apăsa butonul de conectare și a obține mesajul de eroare.

2. 2testfacebook.py -> Acest cod conține două clase: FacebookLoginPage și FacebookHomePage. Clasa FacebookLoginPage definește metode pentru a introduce adresa de email, parola și a apăsa butonul de conectare pe pagina de autentificare a Facebook-ului. 
Clasa FacebookHomePage definește o metodă pentru a verifica vizibilitatea meniului de utilizator de pe pagina principală a Facebook-ului. De asemenea, codul conține două teste care verifică autentificarea cu succes a unui utilizator cu date valide și 
primirea unui mesaj de eroare corespunzător în cazul în care se încearcă autentificarea cu date invalide.

3. test_v2.py ->o alta versiune(tentativa).
